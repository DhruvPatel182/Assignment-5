public class CharacterListItem
{
    public string name { get; set; }
    
    public int age{get; set;}

    
    public string profession { get; set; }
    
    public bool IsFictional { get; set; }
}